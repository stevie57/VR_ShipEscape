﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;
public class StationOnePuzzleState : StationOneState
{
    private StationOneController _station;
    [SerializeField]
    private GameObject _puzzleUI;
    [SerializeField]
    private Image[] _buttonImages = new Image[4];
    [SerializeField]
    private int[] _solution1 = new int[4];
    private bool _displaySolution;
    public override void StateTransitionIn(StationOneController StationOne)
    {
        _station = StationOne;
        _puzzleUI.SetActive(true);
        _displaySolution = true;
        foreach (Image image in _buttonImages)
            image.color = Color.red;
        DisplayPuzzleSolution();
    }

    private void DisplayPuzzleSolution()
    {
        StartCoroutine(PuzzleSolutionRoutine());
    }

    private IEnumerator PuzzleSolutionRoutine()
    {
        while (_displaySolution)
        {
            for (int i = 0; i < _solution1.Length; i++)
            {
                _buttonImages[_solution1[i]].color = Color.green;
                yield return new WaitForSeconds(0.25f);
                _buttonImages[_solution1[i]].color = Color.red;
                yield return new WaitForSeconds(0.1f);
            }
            yield return new WaitForSeconds(1f);
        }
    }

    public override void ButtonNorth()
    {
        throw new System.NotImplementedException();
    }

    public override void ButtonEast()
    {
        throw new System.NotImplementedException();
    }

    public override void ButtonSouth()
    {
        throw new System.NotImplementedException();
    }

    public override void ButtonWest()
    {
        throw new System.NotImplementedException();
    }

    public override void SliderDown()
    {
        throw new System.NotImplementedException();
    }

    public override void SliderUp()
    {
        throw new System.NotImplementedException();
    }

    public override void ButtonConfirm()
    {
        throw new System.NotImplementedException();
    }

    public override void StateTransitionOut()
    {
        _puzzleUI.SetActive(false);
        StopAllCoroutines();
    }
}