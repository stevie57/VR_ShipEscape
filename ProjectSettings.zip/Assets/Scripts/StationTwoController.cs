using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Autohand;
using UnityEngine.UI;

public class StationTwoController : MonoBehaviour
{
    [Header("ShipGun Settings")]
    private bool _isShipGunActive;
    [SerializeField]
    private PhysicsGadgetJoystick _joystick;
    [SerializeField]
    private bool _isInverted;
    [SerializeField]
    Image _targetCursor;
    [SerializeField]
    private float _cursorSensitvity = 0.5f;
    [SerializeField]
    private float _gunRange;
    [SerializeField]
    private Transform _playerHead;
    [SerializeField]
    private LineRenderer _lineRenderer;
    [SerializeField]
    private Transform _shipgun;
    [SerializeField]
    private Transform _shipgunEntrance;
    [SerializeField]
    private ParticleSystem _shipgunPS;
    [SerializeField]
    private Transform _target;
    [SerializeField]
    private float _attackEnergyCost;
    [SerializeField]
    private ShipStatsSO _shipStats;

    private void Awake()
    {
        _isShipGunActive = false;
    }

    private void Start()
    {
        AlignCannon();
    }
    public void ActivateJoystick()
    {
        _isShipGunActive = true;
        StartCoroutine(JoyStickRoutine());
    }

    public void DeactiveJoystick()
    {
        _isShipGunActive = false;
        StopAllCoroutines();
    }

    private IEnumerator JoyStickRoutine()
    {
        while (_isShipGunActive)
        {
            SetTargetCursorPosition();
            AlignCannon();
            CannonAimLine();
            yield return null;
        }
    }

    private void SetTargetCursorPosition()
    {
        Vector2 positionValue = _joystick.GetValue();
        positionValue *= _cursorSensitvity;
        positionValue.y = _isInverted ? positionValue.y * -1 : positionValue.y;
        Vector2 currentPosition = _targetCursor.rectTransform.localPosition;
        Vector2 newPosition = currentPosition + positionValue;
        _targetCursor.rectTransform.localPosition = newPosition;
    }

    private void AlignCannon()
    {
        Vector3 direction = _targetCursor.transform.position - _playerHead.position;
        _target.position = _playerHead.position + direction * _gunRange;
        _shipgun.transform.LookAt(_target.position);
    }

    private void CannonAimLine()
    {
        Vector3 startPos = _shipgunEntrance.position;
        Vector3 endPos = _target.position; //_playerHead.position + (direction * _gunRange);
        Vector3[] positions = new Vector3[2] {startPos, endPos };
        _lineRenderer.SetPositions(positions);
    }

    [ContextMenu("Fire Ship Gun")]
    public void FireShipGun()
    {
        Vector3 direction = _targetCursor.transform.position - _playerHead.position;
        _shipgunPS.Play();

        if (Physics.SphereCast(_playerHead.position, 1f, direction.normalized * _gunRange, out var hitInfo))
        {
            if (hitInfo.transform.GetComponentInParent<IDamageable>() != null)
            {
                hitInfo.transform.GetComponentInParent<IDamageable>().Damaged();
            }
        }

        _shipStats.DecreaseEnergy(_attackEnergyCost);
    }

    [ContextMenu("Reset Ship")]
    public void Reset()
    {
        _shipStats.ResetEnergy();
    }
}
