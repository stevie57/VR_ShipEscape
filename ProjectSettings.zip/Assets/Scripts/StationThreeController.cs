using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class StationThreeController : MonoBehaviour
{
    [SerializeField]
    private WallLever[] _leverArray = new WallLever[6];
    [SerializeField]
    private Image[] _leverSolutionUI = new Image[6];
    [SerializeField]
    private bool[] _leverSolution;
    [SerializeField]
    private TextMeshProUGUI _textMesh;

    public void Start()
    {
        DisplaySolution();
    }

    private void DisplaySolution()
    {
        _leverSolution = new bool[6] { false, true, false, false, false, false };
        for (int i = 0; i < _leverSolution.Length; i++)
        {
            _leverSolutionUI[i].color = _leverSolution[i] ? Color.green : Color.red;
        }
    }

    [ContextMenu("Check Levers")]
    public void CheckLevers()
    {
        bool result = true;
        for(int i = 0; i < _leverSolution.Length; i++)
        {
            if(_leverArray[i].IsActive != _leverSolution[i])
            {
                result = false;
                _textMesh.text = $"Check lever solution is {result} and failed on {i}";
                return;
            }
        }

        _textMesh.text = $"Correct Solution";     
    }
}
