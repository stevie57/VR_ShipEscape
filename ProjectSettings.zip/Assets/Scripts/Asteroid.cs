using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Asteroid : MonoBehaviour, IDamageable
{
    [SerializeField]
    private GameObject _particleExplosion;

    public void Damaged()
    {
        GameObject explosion=  Instantiate(_particleExplosion);
        explosion.transform.position = transform.position;
        Destroy(this.gameObject);
    }
}
