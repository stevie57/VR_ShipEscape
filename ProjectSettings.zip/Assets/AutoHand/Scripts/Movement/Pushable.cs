using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pushable : MonoBehaviour
{
    [Header("BETA")]
    public Vector3 strengthScale = Vector3.one;
}
