﻿using System;

namespace NaughtyAttributes
{
	public enum EConditionOperator
	{
		And,
		Or
	}
}
