using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TextFieldInspector : MonoBehaviour
{
    [TextArea]
    public string text;
}
